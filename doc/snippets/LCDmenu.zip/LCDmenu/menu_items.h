#ifndef MENU_CALLBACK_H_
#define MENU_CALLBACK_H_

/**
 * @name  Structure to represent menu item
 * Represents each menu item. Single MENU_ITEM can contains `render_callback` && `btn_handle_callback` or
 * `submenu_length` && `submenu`.
 * If item has first set, it will be used as final, custom action for menu.
 * If item has second set, it will be used as another step from which the menu nest will proceed.
 */
typedef struct MENU_ITEM
{
	char *title;
	void (*render_callback)(uint8_t which);
	bool (*btn_handle_callback)(MENU_BUTTON *button, uint8_t which);
	uint8_t submenu_length;
	struct MENU_ITEM *submenu;
} MENU_ITEM;

typedef struct MENU_WIDGET
{

// заготовка

} MENU_WIDGET;



MENU_ITEM *menuItemsGetHomeMenu();
uint8_t menuItemsGetHomeMenuSize();

#endif /* MENU_CALLBACK_H_ */


/*
поля ввода вывода которые планируется реализовать
******************************************************

метка (тестовая метка)
***************************
тескт - тест
длинна - 5

ввод/вывод int/float
***************************
контроль - да
максимум - 65535
минимум - 0
переменная - var
тип переменной - int/float
знаков до запятой - 3
знаков после запятой - 1
текст до - test
текст после - test
редактируемое -да/нет ( < > )
длинна - 5

ввод/вывод bool (изменение < > )
***************************
переменная - var
текст true - вкл
текс false - выкл
текст до - test
текст после - test
редактируемое -да/нет
длинна - 5

динамический текст (поле вывода)
***************************
переменная - var
список строк - редактировать
0	резистор
1	конденсатор
2	диод
3	транзистор
длинна - 6

combobox (езменение < > )
***************************
переменная - var
список строк - редактировать
0	мясо
1	хлеб
2	молоко
3	вода
длинна - 6






*/